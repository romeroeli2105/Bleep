import { z } from 'zod';
import { insertSongSchema, songs } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  songs: {
    list: {
      method: 'GET' as const,
      path: '/api/songs',
      responses: {
        200: z.array(z.custom<typeof songs.$inferSelect>()),
      },
    },
    search: {
      method: 'GET' as const,
      path: '/api/songs/search',
      input: z.object({
        q: z.string(),
      }),
      responses: {
        200: z.array(z.custom<typeof songs.$inferSelect>()),
      },
    },
    bleep: {
      method: 'POST' as const,
      path: '/api/songs/bleep',
      input: z.object({
        trackName: z.string(),
        artistName: z.string(),
        artworkUrl: z.string(),
      }),
      responses: {
        200: z.custom<typeof songs.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
