import { ReactNode } from "react";

interface LayoutProps {
  children: ReactNode;
}

export function Layout({ children }: LayoutProps) {
  return (
    <div className="min-h-screen w-full bg-background flex flex-col">
      <main className="flex-1 flex flex-col relative">
        {children}
      </main>
    </div>
  );
}
